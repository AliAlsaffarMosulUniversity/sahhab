// سحّاب — الخلفية: تلتقط روابط الفيديو والملفات من حركة الشبكة لكل تبويب
const DEF_APP = 'https://sahhab.anaqatal-rafidain.workers.dev/';
const PROTECTED = ['youtube.com','youtu.be','googlevideo.com','netflix.com','nflxvideo.net','shahid.mbc.net','osnplus.com','disneyplus.com','primevideo.com','spotify.com','anghami.com','instagram.com','cdninstagram.com','facebook.com','fbcdn.net','fb.watch','tiktok.com','tiktokcdn.com','x.com','twitter.com','twimg.com'];
const FILE_EXT = /\.(mp4|webm|mkv|mov|m4v|avi|wmv|flv|3gp|mp3|m4a|aac|ogg|opus|wav|flac|pdf|zip|rar|7z|tar|gz|iso|apk|exe|msi|dmg|docx?|xlsx?|pptx?|epub)(\?|#|$)/i;
const SKIP = /\.(ts|m4s|aac\?.*seg|key)(\?|#|$)|\/seg[-_]?\d+|[?&](range|bytes)=/i;

function hostOf(u){ try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return ''; } }
function isProtected(u){ const h = hostOf(u); return !!h && PROTECTED.some(p => h === p || h.endsWith('.' + p)); }
function nameOf(u){ try { return decodeURIComponent(new URL(u).pathname.split('/').filter(Boolean).pop() || hostOf(u)); } catch (e) { return u; } }

async function getApp(){
  const { app } = await chrome.storage.sync.get('app');
  let a = (app || DEF_APP).trim();
  if (!a.endsWith('/') && !/\.html$/.test(a)) a += '/';
  return a;
}
async function openApp(params){
  const app = await getApp();
  const qs = Object.entries(params).map(([k, v]) => k + '=' + encodeURIComponent(v)).join('&');
  chrome.tabs.create({ url: app + '?' + qs });
}

// ---------- سجل الروابط لكل تبويب ----------
const key = id => 't' + id;
async function getList(tabId){ const o = await chrome.storage.session.get(key(tabId)); return o[key(tabId)] || []; }
async function setList(tabId, list){
  await chrome.storage.session.set({ [key(tabId)]: list });
  chrome.action.setBadgeText({ tabId, text: list.length ? String(list.length) : '' });
  chrome.action.setBadgeBackgroundColor({ tabId, color: '#0F6E66' });
}
let queue = Promise.resolve();
function addItem(tabId, item){
  queue = queue.then(async () => {
    const list = await getList(tabId);
    if (list.some(x => x.url === item.url)) return;
    list.unshift(item);
    await setList(tabId, list.slice(0, 40));
  }).catch(() => {});
}

chrome.webRequest.onHeadersReceived.addListener(d => {
  if (d.tabId < 0 || d.method !== 'GET' || d.statusCode >= 400) return;
  if (isProtected(d.url) || (d.initiator && isProtected(d.initiator))) return;
  if (SKIP.test(d.url)) return;
  const h = {}; (d.responseHeaders || []).forEach(x => { h[x.name.toLowerCase()] = x.value || ''; });
  const ct = (h['content-type'] || '').toLowerCase();
  let size = +(h['content-length'] || 0);
  const cr = /\/(\d+)$/.exec(h['content-range'] || ''); if (cr) size = +cr[1];
  let kind = '';
  if (/mpegurl/.test(ct) || /\.m3u8(\?|#|$)/i.test(d.url)) kind = 'stream';
  else if (/^video\//.test(ct) && !/mp2t/.test(ct)) kind = 'video';
  else if (/^audio\//.test(ct)) kind = 'audio';
  else if (FILE_EXT.test(d.url) && (d.type === 'main_frame' || d.type === 'sub_frame' || d.type === 'other' || d.type === 'media' || d.type === 'xmlhttprequest')) kind = 'file';
  else if (/attachment/i.test(h['content-disposition'] || '')) kind = 'file';
  if (!kind) return;
  if ((kind === 'video' || kind === 'audio') && size && size < 150 * 1024) return;   // مقاطع صغيرة جداً
  addItem(d.tabId, { url: d.url, kind, size, name: nameOf(d.url), t: Date.now() });
}, { urls: ['<all_urls>'] }, ['responseHeaders']);

// تفريغ القائمة عند الانتقال إلى صفحة أخرى
chrome.tabs.onUpdated.addListener((tabId, info) => { if (info.status === 'loading' && info.url) setList(tabId, []); });
chrome.tabs.onRemoved.addListener(tabId => chrome.storage.session.remove(key(tabId)));

// ---------- القائمة عند النقر بالزر الأيمن ----------
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: 'link', title: 'نزّل الرابط بسحّاب', contexts: ['link'] });
    chrome.contextMenus.create({ id: 'media', title: 'نزّل هذا بسحّاب', contexts: ['video', 'audio', 'image'] });
    chrome.contextMenus.create({ id: 'page', title: 'استخرج ملفات هذه الصفحة بسحّاب', contexts: ['page'] });
  });
});
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === 'link') return openApp({ url: info.linkUrl });
  if (info.menuItemId === 'media'){
    if (info.srcUrl && /^https?:/.test(info.srcUrl)) return openApp({ url: info.srcUrl });
    return sendDetected(tab);
  }
  if (info.menuItemId === 'page') return sendDetected(tab, true);
});

async function sendDetected(tab, preferPage){
  const list = tab ? await getList(tab.id) : [];
  const media = list.filter(x => x.kind !== 'file');
  if (media.length === 1 && !preferPage) return openApp({ url: media[0].url });
  if (list.length) return openApp({ list: list.map(x => x.url).join('\n') });
  if (tab && tab.url) return openApp({ page: tab.url });
}

// ---------- التقاط تنزيلات المتصفح (اختياري، مثل IDM) ----------
chrome.downloads.onCreated.addListener(async item => {
  const { capture } = await chrome.storage.sync.get('capture');
  if (!capture) return;
  const u = item.finalUrl || item.url;
  if (!/^https?:/.test(u) || isProtected(u)) return;
  const app = await getApp();
  if (u.startsWith(new URL(app).origin)) return;
  try { await chrome.downloads.cancel(item.id); await chrome.downloads.erase({ id: item.id }); } catch (e) {}
  openApp({ url: u });
});

// ---------- الرسائل من النافذة والصفحات ----------
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  (async () => {
    if (msg.type === 'list') reply(await getList(msg.tabId ?? sender.tab.id));
    else if (msg.type === 'send'){ await openApp({ url: msg.url }); reply(true); }
    else if (msg.type === 'sendMany'){ await openApp({ list: msg.urls.join('\n') }); reply(true); }
    else if (msg.type === 'videoClick'){
      // زر الفيديو: نستعمل رابط الفيديو إن كان مباشراً، وإلا ما التقطناه من الشبكة
      if (msg.src && /^https?:/.test(msg.src) && !isProtected(msg.src)) await openApp({ url: msg.src });
      else await sendDetected(sender.tab);
      reply(true);
    }
    else if (msg.type === 'protected') reply(isProtected(msg.url));
  })();
  return true;
});
