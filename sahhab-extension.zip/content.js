// سحّاب — زر عائم فوق الفيديو، مثل زر IDM
(() => {
  if (window.__sahhab) return; window.__sahhab = true;
  const PROTECTED = /(^|\.)(youtube\.com|youtu\.be|netflix\.com|shahid\.mbc\.net|osnplus\.com|disneyplus\.com|primevideo\.com|spotify\.com|anghami\.com|instagram\.com|facebook\.com|tiktok\.com|x\.com|twitter\.com)$/i;
  let top = location.hostname;
  try { top = (window.top.location.hostname) || top; } catch (e) {}
  if (PROTECTED.test(location.hostname.replace(/^www\./, '')) || PROTECTED.test(top.replace(/^www\./, ''))) return;

  const host = document.createElement('div');
  host.style.cssText = 'position:fixed;z-index:2147483647;top:0;left:0;display:none;';
  const root = host.attachShadow({ mode: 'closed' });
  root.innerHTML = `<style>
    button{all:initial;display:flex;align-items:center;gap:6px;cursor:pointer;
      background:#0F6E66;color:#fff;font:600 13px system-ui,"Segoe UI",Tahoma,sans-serif;
      padding:7px 12px 7px 10px;border-radius:9px;box-shadow:0 2px 10px rgba(0,0,0,.35);direction:rtl}
    button:hover{background:#0b5a53}
    button:focus-visible{outline:3px solid #E0A526;outline-offset:2px}
    svg{width:16px;height:16px}
    .x{all:initial;cursor:pointer;color:#fff;background:rgba(0,0,0,.45);border-radius:50%;width:18px;height:18px;
      display:grid;place-items:center;font:12px system-ui;position:absolute;top:-8px;left:-8px}
  </style>
  <div style="position:relative">
    <button id="b" title="نزّل هذا الفيديو بسحّاب">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11M7 10l5 5 5-5M5 20h14"/></svg>
      <span>نزّل بسحّاب</span>
    </button>
    <span class="x" id="x" title="إخفاء">×</span>
  </div>`;
  (document.body || document.documentElement).appendChild(host);

  let current = null, hideT = null, dismissed = new WeakSet();
  const show = v => {
    const r = v.getBoundingClientRect();
    host.style.top = Math.max(4, r.top + 10) + 'px';
    host.style.left = Math.max(4, r.right - 150) + 'px';
    host.style.display = 'block';
    current = v;
    clearTimeout(hideT); hideT = setTimeout(hide, 3500);
  };
  const hide = () => { host.style.display = 'none'; current = null; };

  let last = 0;
  document.addEventListener('mousemove', e => {
    const now = Date.now(); if (now - last < 150) return; last = now;
    if (host.contains(e.target)) return;
    for (const v of document.querySelectorAll('video')){
      if (dismissed.has(v)) continue;
      const r = v.getBoundingClientRect();
      if (r.width < 200 || r.height < 110) continue;
      if (e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom){ show(v); return; }
    }
  }, { passive: true, capture: true });
  window.addEventListener('scroll', () => { if (current) show(current); }, { passive: true });

  root.getElementById('x').addEventListener('click', e => { e.stopPropagation(); if (current) dismissed.add(current); hide(); });
  root.getElementById('b').addEventListener('click', e => {
    e.stopPropagation();
    const v = current; if (!v) return;
    const src = v.currentSrc || v.src || (v.querySelector('source') || {}).src || '';
    chrome.runtime.sendMessage({ type: 'videoClick', src });
    hide();
  });
})();
