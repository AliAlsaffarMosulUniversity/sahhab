const DEF_APP = 'https://sahhab.anaqatal-rafidain.workers.dev/';
const TAG = { stream: 'بث', video: 'فيديو', audio: 'صوت', file: 'ملف' };
const $ = s => document.querySelector(s);
const fmt = n => { if (!n) return ''; const u = ['B','KB','MB','GB']; let i = 0; while (n >= 1024 && i < 3){ n /= 1024; i++; } return n.toFixed(i ? 1 : 0) + ' ' + u[i]; };

(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const { app, capture } = await chrome.storage.sync.get(['app', 'capture']);
  $('#app').value = app || DEF_APP;
  $('#capture').checked = !!capture;
  $('#app').addEventListener('change', () => chrome.storage.sync.set({ app: $('#app').value.trim() || DEF_APP }));
  $('#capture').addEventListener('change', () => chrome.storage.sync.set({ capture: $('#capture').checked }));
  $('#openApp').addEventListener('click', e => { e.preventDefault(); chrome.tabs.create({ url: $('#app').value || DEF_APP }); });

  if (tab && tab.url && await chrome.runtime.sendMessage({ type: 'protected', url: tab.url })) $('#warn').hidden = false;

  const list = tab ? await chrome.runtime.sendMessage({ type: 'list', tabId: tab.id }) : [];
  const box = $('#list');
  if (!list.length){
    box.outerHTML = '<div class="empty">لم يُلتقط شيء في هذه الصفحة بعد.<br>شغّل الفيديو قليلاً ثم افتح هذه النافذة مرة أخرى.</div>';
    $('#all').disabled = true;
  } else {
    list.forEach(it => {
      const row = document.createElement('div'); row.className = 'it';
      row.innerHTML = `<span class="tag"></span><span class="nm"></span><span class="sz"></span><button>تنزيل</button>`;
      row.querySelector('.tag').textContent = TAG[it.kind] || 'ملف';
      row.querySelector('.nm').textContent = it.name; row.querySelector('.nm').title = it.url;
      row.querySelector('.sz').textContent = fmt(it.size);
      row.querySelector('button').onclick = async () => { await chrome.runtime.sendMessage({ type: 'send', url: it.url }); window.close(); };
      box.appendChild(row);
    });
  }
  $('#all').onclick = async () => { await chrome.runtime.sendMessage({ type: 'sendMany', urls: list.map(x => x.url) }); window.close(); };
  $('#page').onclick = () => { chrome.tabs.create({ url: ($('#app').value || DEF_APP) + '?page=' + encodeURIComponent(tab.url) }); window.close(); };
})();
